package com.honq.boost

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.os.BatteryManager
import java.io.File

object Stats {
    private fun mem(c: Context): ActivityManager.MemoryInfo {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    fun ramTotalMb(c: Context): Int = (mem(c).totalMem / 1048576L).toInt()
    fun ramUsedMb(c: Context): Int {
        val m = mem(c)
        return ((m.totalMem - m.availMem) / 1048576L).toInt()
    }
    fun ramPercent(c: Context): Int {
        val m = mem(c)
        return (((m.totalMem - m.availMem) * 100L) / m.totalMem).toInt()
    }

    private fun battery(c: Context): Intent? =
        c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    fun batteryPct(c: Context): Int {
        val i = battery(c) ?: return 0
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return l * 100 / s
    }

    fun tempC(c: Context): Float =
        (battery(c)?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

    fun gpuBusy(): String {
        return try {
            val f = File("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage")
            if (f.canRead()) f.readText().trim() else "N/A"
        } catch (e: Exception) {
            "N/A"
        }
    }

    fun cleanRam(c: Context): Int {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        for (app in c.packageManager.getInstalledApplications(0)) {
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if (app.packageName == c.packageName) continue
            try {
                am.killBackgroundProcesses(app.packageName)
                n++
            } catch (e: Exception) {
            }
        }
        return n
    }
}
